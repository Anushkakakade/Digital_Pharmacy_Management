<?php
session_start();
include('config/db.php');

if (isset($_POST['save_btn'])) {
    $name = mysqli_real_escape_string($conn, $_POST['medicine_name']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $price = $_POST['price'];
    $stock = $_POST['stock_quantity'];
    $expiry = mysqli_real_escape_string($conn, $_POST['expiry_date']);
    // Checkbox logic: if checked it's 1, else 0
    $prescription = isset($_POST['prescription']) ? 1 : 0;

    $query = "INSERT INTO medicines (medicine_name, category, price, stock_quantity, prescription_required, expiry_date) 
              VALUES ('$name', '$category', '$price', '$stock', '$prescription', '$expiry')";

    if (mysqli_query($conn, $query)) {
        $_SESSION['status'] = "Medicine Added Successfully!";
        header("Location: dashboard.php");
    } else {
        $_SESSION['status'] = "Error: " . mysqli_error($conn);
        header("Location: dashboard.php");
    }
}
?>
